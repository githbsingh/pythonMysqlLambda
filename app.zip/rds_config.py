#config file containing credentials for RDS MySQL instance
db_username = "manohardbdev"
db_password = "admindev"
db_name = "ExampleDB"